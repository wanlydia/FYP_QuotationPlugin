function toggleSingleButton(button, ...otherButtons) {
    button.classList.toggle('active');
    otherButtons.forEach(btn => {
        const otherButton = document.getElementById(btn);
        if (otherButton !== button) {
            otherButton.classList.remove('active');
        }
    });
}

function toggleContainer(containerId, button) {
    const container = document.getElementById(containerId);
    const isDisplayed = container.style.display === 'block';
    container.style.display = isDisplayed ? 'none' : 'block';
    button.classList.toggle('active', !isDisplayed);
}

function togglePaintingButton(section, level) {
    const buttons = document.querySelectorAll(`#painting-grp-${section} button`);
    buttons.forEach(btn => {
        if (btn.id.includes(level)) {
            btn.classList.toggle('active');
        } else {
            btn.classList.remove('active');
        }
    });
}

function toggleFlooringButton(section, level) {
    const buttons = document.querySelectorAll(`#flooring-grp-${section} button`);
    buttons.forEach(btn => {
        if (btn.id.includes(level)) {
            btn.classList.toggle('active');
        } else {
            btn.classList.remove('active');
        }
    });
}

function nextPage(pageId) {
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => {
        page.style.display = 'none';
    });
    const nextPage = document.getElementById(pageId);
    if (nextPage) {
        nextPage.style.display = 'block';
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const livingBtn = document.getElementById('living-btn');
    const kitchenBtn = document.getElementById('kitchen-btn');

    livingBtn.addEventListener('click', () => {
        livingBtn.classList.toggle('active');
        if (kitchenBtn.classList.contains('active')) {
            kitchenBtn.classList.remove('active');
        }
    });

    kitchenBtn.addEventListener('click', () => {
        kitchenBtn.classList.toggle('active');
        if (livingBtn.classList.contains('active')) {
            livingBtn.classList.remove('active');
        }
    });
});
