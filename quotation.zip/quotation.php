<?php
/*
Plugin Name: Quotation
Description: A plugin to display a renovation cost calculator.
Version: 1.0
Author: Lydia, Chloe
Author URI: https://github.com/wanlydia, https://github.com/CrossoverRed 
License: GPL2
*/

// Enqueue scripts and styles
function rq_enqueue_scripts() {
    wp_enqueue_style('rq-styles', plugins_url('styles.css', __FILE__));
    wp_enqueue_script('rq-script', plugins_url('quotation-script.js', __FILE__), array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'rq_enqueue_scripts');

// Shortcode function for the calculator
function rq_display_calculator() {
    ob_start(); ?>
    <div id="pg1" class="page active">
        <h3>FIND THE PRICE OF SERVICE AT THE PRICE OF NONE</h3>
        <div class="Group-1">
            <div class="property-status-grp">
                <p>Property Status</p>
                <div class="button-container1">
                    <button id="btn-1q" class="common-btn" type="button" onclick="toggleSingleButton(this, 'btn-1q', 'btn-2q')">New</button>
                    <button id="btn-2q" class="common-btn" type="button" onclick="toggleSingleButton(this, 'btn-2q', 'btn-1q')">Resale</button>
                </div>
            </div>
            <div class="property-type-grp">
                <p>Property Type</p>
                <div class="button-container2">
                    <button id="btn-3q" class="common-btn" type="button" onclick="toggleSingleButton(this, 'btn-3q', 'btn-4q', 'btn-5q')">HDB</button>
                    <button id="btn-4q" class="common-btn" type="button" onclick="toggleSingleButton(this, 'btn-4q', 'btn-3q', 'btn-5q')">Condo</button>
                    <button id="btn-5q" class="common-btn" type="button" onclick="toggleSingleButton(this, 'btn-5q', 'btn-3q', 'btn-4q')">Landed</button>
                </div>
            </div>
        </div>
        <div class="Group-2">
            <div class="renovate-grp">
                <p>What To Renovate?</p>
                <div class="button-container">
                    <button id="living-btn" class="common-btn">Living</button>
                    <button id="kitchen-btn" class="common-btn">Kitchen</button>
                    <button id="bathroom-btn" class="common-btn" onclick="toggleContainer('bathrooms-container', this)">Bathroom</button>
                    <button id="bedroom-btn" class="common-btn" onclick="toggleContainer('bedrooms-container', this)">Bedroom</button>
                </div>
            </div>
        
            <div class="bath-bed-group"> 
                <div id="bathrooms-container" style="display: none;">
                    <label for="bathrooms-box" id="bathrooms-txt">No. of Bathrooms</label> 
                    <input type="number" id="bathrooms-box" name="bathrooms" placeholder="No." min="1" max="5">
                </div>
                <br>
                <div id="bedrooms-container" style="display: none;">
                    <label for="bedrooms-box" id="bedrooms-txt">No. of Bedrooms</label> 
                    <input type="number" id="bedrooms-box" name="bedrooms" placeholder="No." min="1" max="5">
                </div>
            </div>
        </div>
        <br>
        <h2>Living</h2>
        <div id="Living-Group">
            <div id="painting-grp-living">
                <p>PAINTING</p>
                <button id="painting-light-btn" class="common-btn" type="button" onclick="togglePaintingButton('living', 'light')">Light</button>
                <button id="painting-moderate-btn" class="common-btn" type="button" onclick="togglePaintingButton('living', 'moderate')">Moderate</button>
                <button id="painting-extensive-btn" class="common-btn" type="button" onclick="togglePaintingButton('living', 'extensive')">Extensive</button>
            </div>
            <div id="flooring-grp-living">
                <p>FLOORING</p>
                <button id="flooring-light-btn" class="common-btn" type="button" onclick="toggleFlooringButton('living', 'light')">Light</button>
                <button id="flooring-moderate-btn" class="common-btn" type="button" onclick="toggleFlooringButton('living', 'moderate')">Moderate</button>
                <button id="flooring-extensive-btn" class="common-btn" type="button" onclick="toggleFlooringButton('living', 'extensive')">Extensive</button>
            </div>
        </div>
        <br>
        <h2>KITCHEN</h2>
        <div id="Kitchen-Group">
            <div class="hacking-grp-kitchen">
                <p>HACKING</p>
                <button id="hack-light-btn-kitchen" class="common-btn" type="button">Light</button>
                <button id="hack-moderate-btn-kitchen" class="common-btn" type="button">Moderate</button>
                <button id="hack-extensive-btn-kitchen" class="common-btn" type="button">Extensive</button>
            </div>
            <div class="masonry-grp-kitchen">
                <p>MASONRY</p>
                <button id="masonry-light-btn" class="common-btn" type="button">Light</button>
                <button id="masonry-moderate-btn" class="common-btn" type="button">Moderate</button>
                <button id="masonry-extensive-btn" class="common-btn" type="button">Extensive</button>
            </div>
        </div>
        <br>
        <h2>BEDROOM</h2>
        <div id="Bedroom-Group">
            <div id="painting-grp-bedroom">
                <p>PAINTING</p>
                <button id="painting-light-btn-bed" class="common-btn" type="button" onclick="togglePaintingButton('bedroom', 'light')">Light</button>
                <button id="painting-moderate-btn-bed" class="common-btn" type="button" onclick="togglePaintingButton('bedroom', 'moderate')">Moderate</button>
                <button id="painting-extensive-btn-bed" class="common-btn" type="button" onclick="togglePaintingButton('bedroom', 'extensive')">Extensive</button>
                <p id="sentence-3"></p>
            </div>
            <div id="flooring-grp-bedroom">
                <p>FLOORING</p>
                <button id="flooring-light-btn-bed" class="common-btn" type="button" onclick="toggleFlooringButton('bedroom', 'light')">Light</button>
                <button id="flooring-moderate-btn-bed" class="common-btn" type="button" onclick="toggleFlooringButton('bedroom', 'moderate')">Moderate</button>
                <button id="flooring-extensive-btn-bed" class="common-btn" type="button" onclick="toggleFlooringButton('bedroom', 'extensive')">Extensive</button>
                <p id="sentence-4"></p>
            </div>
        </div>
        <br>
        <h2>BATHROOM</h2>
        <div id="Bathroom-Group">
            <div id="painting-grp-bathroom">
                <p>PAINTING</p>
                <button id="painting-light-btn-bath" class="common-btn data-paintBath" min="10" max="20" type="button">Light</button>
                <button id="painting-moderate-btn-bath" class="common-btn data-paintBath" min="20" max="30" type="button">Moderate</button>
                <button id="painting-extensive-btn-bath" class="common-btn data-paintBath" min="30" max="40" type="button">Extensive</button>
            </div>
            <div id="tiling-grp-bathroom">
                <p>TILING</p>
                <button id="tiling-light-btn" class="common-btn data-tileBath" min="10" max="20" type="button">Light</button>
                <button id="tiling-moderate-btn" class="common-btn data-tileBath" type="button">Moderate</button>
                <button id="tiling-extensive-btn" class="common-btn data-tileBath" type="button">Extensive</button>
            </div>
        </div>
        <br>
        <button id="btn-10q" class="common-btn" type="button" onclick="nextPage('pg6')">Next</button>
    </div>
    
    <div id="pg6" class="page" style="display:none;">
        <div id="rq_resultsContainer">
            <h2 id="review-header">Review Results</h2>
            <p id="est-reno-txt">Your estimated renovation cost is</p>
            <div id="rq-results">
                <div id="rq-minResults">$15.8K</div> - <div id="rq-maxResults">$25.5K</div>
            </div>
            <div id="rq_links">
                <p id="text">Ready to start your project? <a href="https://renoku2.azharapp.com/contact-us/" class="highlight">BOOK YOUR APPOINTMENT NOW</a></p>
                <p id="text">Want to know what we can do? <a href="https://renoku2.azharapp.com/gallery/" class="highlight">CHECK OUR GALLERY OF WORKS</a></p>
            </div>
        </div>
        <button class="common-btn" onclick="nextPage('pg1')">Start Over</button>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('rq_quotation', 'rq_display_calculator');
?>
